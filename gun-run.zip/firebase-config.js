/* GUN RUN — ключі Firebase для онлайну й акаунтів.
   1) Створи проєкт на https://console.firebase.google.com
   2) Додай веб-застосунок (значок </>) і скопіюй сюди значення з firebaseConfig.
   3) Обов'язково заповни databaseURL (Realtime Database → адреса вгорі сторінки).
   Поки apiKey порожній, гра працює без онлайну (усе інше доступне). */
window.GUNRUN_FIREBASE = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
